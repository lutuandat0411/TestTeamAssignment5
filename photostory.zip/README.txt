A Pen created at CodePen.io. You can find this one at https://codepen.io/bcarvalho/pen/RZqmZX.

 A responsive slider  timeline made with Swiper lib.